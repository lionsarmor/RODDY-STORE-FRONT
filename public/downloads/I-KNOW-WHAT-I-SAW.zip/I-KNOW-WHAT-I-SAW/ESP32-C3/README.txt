I KNOW WHAT I SAW — ESP32-C3 Super Mini firmware

Merged firmware includes bootloader, partition table and game; flash at 0x0.
Built with ESP-IDF 5.4.4. Only flash to an ESP32-C3 with this exact peripheral wiring.
Hardware is not yet tested. Back up existing firmware/saves before flashing;
flashing replaces the firmware on the device. No erase-flash step is required.

Install Python 3 and esptool:
  python -m pip install "esptool>=4.8,<5"
Put the C3 into USB download mode (hold BOOT, tap RESET, release BOOT).
Windows example (replace COM3 with your device's port):
  py -m esptool --chip esp32c3 --port COM3 --baud 460800 write_flash 0x0 I-KNOW-WHAT-I-SAW-ESP32-C3.bin
Linux example (replace the port as needed):
  python3 -m esptool --chip esp32c3 --port /dev/ttyACM0 --baud 460800 write_flash 0x0 I-KNOW-WHAT-I-SAW-ESP32-C3.bin
Reset after flashing. A+B together acts as START.

Display: 1.69-inch ST7789 240x280 SPI; SCL GPIO4, SDA/MOSI GPIO6,
RES GPIO7, DC GPIO2, CS GPIO10, BLK 3V3.
Buttons: PCF8574 address 0x20, SDA GPIO8, SCL GPIO9.
P0 up, P1 down, P2 left, P3 right, P4 A, P5 B, P6 optional START.
Audio MAX98357A: BCLK GPIO21, LRC GPIO0, DIN GPIO20, SD GPIO5, GAIN unconnected.
Vibration IN GPIO3; IR TX GPIO1. UART0 pins 20/21 are used for audio;
logs use native USB. GPIO2/8/9 are strapping pins; do not add pull-downs.
Display orientation/colour order may need a custom firmware build for other panels.
