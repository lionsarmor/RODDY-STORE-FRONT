#!/bin/sh
cd "$(dirname "$0")" && exec ./iknowwhatisaw "$@"
