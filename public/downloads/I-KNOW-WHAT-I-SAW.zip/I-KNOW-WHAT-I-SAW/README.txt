I KNOW WHAT I SAW — Windows, Linux and ESP32-C3

Extract this entire folder before playing. No GitHub account or source checkout is needed.

WINDOWS (64-bit): Open Windows/iknowwhatisaw.exe.
Keep SDL2.dll next to the EXE. This independent release is not code signed.

LINUX (64-bit x86): In Linux/, run chmod +x run.sh iknowwhatisaw, then ./run.sh.
SDL2 is included in lib/. Built on Ubuntu 22.04; requires glibc 2.35+ and
normal desktop graphics/audio libraries. Not an ARM/Raspberry Pi build.

CONTROLS: Arrows/WASD move; Z/Space = A; X = B; Enter = START;
Esc = menu; F11/Alt+Enter = fullscreen. USB gamepads supported.
Saves: Windows %APPDATA%/Weeks/I Know What I Saw/
       Linux ~/.local/share/Weeks/I Know What I Saw/

ESP32-C3 HANDHELD: Firmware in ESP32-C3/ targets ONLY the ESP32-C3 Super Mini
with the wiring described in ESP32-C3/README.txt. It is not a generic ESP32
or ESP32-S3 build. Hardware playback has not been verified.

Follow each platform's instructions. Do not copy this PC game to an X16 SD card.
