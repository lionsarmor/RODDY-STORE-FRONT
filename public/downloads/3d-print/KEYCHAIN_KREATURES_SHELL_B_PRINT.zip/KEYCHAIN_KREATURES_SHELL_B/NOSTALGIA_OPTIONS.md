# Bezel and colour options

Supplied CAD includes the tapered integral top eyelet, rounded replaceable screen bezel, an alternate bezel with three engraved retro computer lines, and separate button caps. Roddy uses cream, black and red; alternate previews use avocado/yellow and beige/brown.

The badge and grip/protector proposals were rejected. Current print kits contain enclosure B alone, without a saddle, bumper or protector. Historical studies are excluded from current downloads.

The screen is blank in engineering CAD previews. The storefront creature is illustrative artwork, not a firmware screenshot.

Fit one bezel at a time. Keep the display, indicator, IR apertures, button travel and case releases clear. The concealed bezel springs need their clearance channels; removal uses access behind the front shell. Printed fit and durability require physical checks.
