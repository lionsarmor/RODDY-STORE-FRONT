# C.7/P.5 internal assembly and original shell A printing

**Current shell B:** use [its print and bezel instructions](README.md). The internal assembly sequence below still applies. References to `mechanical/stl` and the bottom cord lug describe the preserved original A shell.

Use a Bambu enclosed printer with a 0.4 mm nozzle and its correct ABS profile. These parts are a fit-test prototype; record the printer model, spool, drying, chamber conditions and coupon results before changing clearances.

## Print and fit

Start at 0.2 mm layers, four wall loops and five top/bottom layers. Use the filament maker's temperatures and the [Bambu ABS guidance](https://bambulab.com/filament/abs); do not copy a universal temperature into a different printer. Keep the enclosure warm, dry the filament as directed, use suitable bed adhesion and a brim if required. Keep ABS ventilation appropriate to the printer location.

The STLs in `mechanical/stl` have their intended bed face at Z=0. The manifest records the orientation. The front prints outside face down; the rear prints rear face down. Caps print visible face down with a sloped retention transition. Clips print with their long beam in XY so bending does not pull Z layers apart. The battery cradle prints flat exterior down with its bore open upward. The display frame and retainers print flat.

Inspect support needs in the slicer. Small latch-seat recesses and internal pockets may need local support; keep support contact off clip arms, locating tongues, button guides, insert bores and display seats. Use snug supports only where the exact printer's bridging cannot produce a clean surface. A watertight STL is not a guarantee of support-free printing.

Print `snap_fit_coupons.stl` first. Its four mating pairs exercise 0.2, 0.3, 0.4 and 0.5 mm per-side root/neck clearances. Their male clips include a free beam, not a beam glued to a test plate. These coupons check fit and beam print quality; test the complete catch and retention in the assembled case. Measure printed dimensions after cooling, remove the brim/elephant foot, and select a fit that closes without permanent clip deformation. The default case clearance is 0.4 mm. Adjust the relevant CAD dimensions in a fresh copy and rebuild when adjustment is needed; avoid scaling the whole enclosure because this changes mounting and display dimensions.

Keep the snap arms free of infill voids and inspect layer adhesion. The arm is 18 × 1.3 × 4 mm with 1 mm overlapping its root, giving roughly 17 mm free span. At 0.5 mm deflection, uniform-beam screening gives about 0.34% outer-fiber strain; the root fillet and printed material require physical testing. Measure actual forces and cycling. ABS shrinkage, creep, build orientation and root finish govern service life. [Prusa's FDM design guidance](https://help.prusa3d.com/article/modeling-with-3d-printing-in-mind_164135) explains why orientation, clearances, chamfers and support access require process-specific choices.

## Assembly order

1. Deburr parts, clean button guides and inspect every clip. Install M2 heat-set inserts using a controlled tool and the insert maker's procedure. The nominal 3.3 mm bores are provisional; use an insert coupon before heating a finished shell. Keep hardware and insert tips clear of electronics.
2. The supplied factory pack must already be welded, insulated and fitted with its bonded NTC and pigtails. Install the battery cradle, retaining textile strap and pull loop. Never solder directly to a cell. Keep battery leads out of the hatch edge and snap seats.
3. Install the speaker and motor in their retainers with suitable foam and strain relief. Keep foam off the speaker cone. Install the factory-prepared switch harness and its mechanical support; wires must not carry slide-actuation loads. Qualify that harness fixture against the delivered switch before kit production.
4. Install the independently tested power board on its four separate supports. Its component side faces toward the main board. Connect battery VH and NTC PH leads to their labeled power-board connectors. Secure the NTC branch as part of the factory battery/power subassembly so it cannot be confused with the main motor plug during normal user fitting.
5. Assemble the THT main board following the candidate BOM, not the C.6 placement sheet. Use the required insulating supports under formed horizontal parts. Check the new display logic components and connector pin numbering. Do not change module/socket pin mappings based on seller photographs.
6. Inspect the screen-facing solder joints and lead tails. Keep the finished joint envelope no higher than 1.0 mm above the PCB face; dress sharp tails. The LCD carrier underside is at Z=4.7 mm with the main PCB front at Z=1.6 mm. Check every actual joint under the display and insulate where required without eliminating the designed clearance.
7. With the main board still accessible, fit the keyed four-wire supply harness, speaker XH, motor PH and display harness. Route display wiring along the module's right side to the front-side horizontal main header below the display. Leave service loops; keep wires away from button stems, clip arms, the antenna nose and screw tips. Check fully mated plug bodies and minimum bend radii on real harnesses.
8. Seat the main board on its five M2 supports. Confirm the power-board connectors and leads clear the main's rear components. Place the display frame and attach the LCD using verified-length M2.5 screws. Fit its two M2 carrier fasteners without loading the glass.
9. Place nine button caps into their guides in the front shell. Check a small rest gap and free return at every switch. The 0.8 mm mechanical stop is provisional until measured against the actual soft switch; the stop must limit travel before the switch is overloaded.
10. Fit the four replaceable clips into the rear seats. Align the tongue and close evenly. Record insertion force and check all catches engage. Use the release slots to reopen; do not twist the LCD or pull on the cord lug to split the halves.
11. Close the battery hatch using the specified M2 captive-screw arrangement. Prove screw retention on the printed hatch before supplying it to users. Use the pull loop to withdraw the pack for inspection without pulling its leads. Full replacement requires opening the main shell and lifting the main board to reach both battery and NTC connectors; use qualified service procedures and insulate the live power assembly.

## Harness checks and power-up

Power J3 to main J1 is **1 MCU_5V, 2 GND, 3 LOGIC_3V3, 4 ACT_3V2**. Check continuity end-to-end before connecting either board. Battery J2 is **1 CELL_PLUS, 2 BAT_NEG**. BAT_NEG is not GND. Neither speaker terminal is ground. Charger USB has no data path to the MCU; qualify ESP32 USB reverse-feed behavior before simultaneous connection with external rails.

Use the inherited [P.4 current-limited power qualification procedure](INHERITED_P4_POWER_BENCH_PROCEDURE.md) for the unchanged circuit, together with P.5's connector map and fresh reports. Begin with a current-limited battery simulator and no main board or real cell. Test the new remote switch in both positions, NTC faults and safe rail shutdown before adding loads. Real battery charging requires the qualified pack and supervised thermal testing.

## Hardware quantities to resolve on the physical sample

The design uses five main M2 fasteners, four power M2 fasteners, two battery-carrier M2 fasteners, two display-carrier M2 fasteners, two motor-carrier M2 fasteners, two speaker-retainer M2 fasteners, two switch-retainer M2 fasteners, four display M2.5 fasteners and one battery-hatch M2 captive fastener. Inserts, washers, thread engagement and screw lengths must match purchased hardware; the candidate does not infer these from generic M2 names. Include the textile strap, pull loop, foam, harness restraints and electrical insulation in the kit BOM.

## Fastener procurement envelopes

The CAD checks include heads and insulating washers. M2 heads must be no larger than 3.8 mm diameter and 1.2 mm high; insulating washers must be no larger than 4.0 mm diameter and 0.3 mm thick. Display M2.5 heads must be no larger than 4.7 mm diameter and 1.3 mm high, with washers at most 5.0 mm diameter and 0.2 mm thick. Larger socket heads or ordinary large washers can collide even if the thread size matches.

Starting under-head length targets are M2×5 for main and power boards, M2×6 for the battery carrier, M2×4 for the display carrier, motor carrier and speaker retainer, and M2×5 for the switch retainer. Display M2.5×4 gives about 2.8 mm engagement after the 1.0 mm carrier and 0.2 mm washer. Verify every supplied insert, screw and display thread depth before adopting these lengths. The captive hatch screw and retaining washer need a matched supplier selection and physical retention check. Threads, insert installation and captive retention are not established by head-envelope models.
