# Keychain Kreatures — enclosure B

Open [OPEN_ME.html](OPEN_ME.html) for current CAD renders and the complete print kit. B retains the C.7 main / P.5 power boards and all internal mounting positions. The old broad-slot trim previews are superseded.

The integral top eyelet has a **30 mm outside diameter and 12 mm throat**. Its 30 mm wide shoulder fills the **33 mm rear-shell depth** at the root; the back tapers at 45 degrees toward the nose. The rear of the bore flares for cord/ring clearance. The former bottom cord lug is removed. This spreads the load over a broader shoulder, but no pull/drop rating is established. Verify actual ring articulation; a soft cord or short connector may suit the deep shoulder better. A metal ring near the antenna also needs an RF check.

The bezel is a continuous rounded surround inspired by a small CRT, with a shallow sloping aperture and concealed hooks. Its four flexible arms belong to the front shell and sit under the trim. Choose **one** bezel: smooth, or the alternative with three engraved vintage-computer trim lines. The inner opening remains 58.8 × 44.4 mm; neither trim covers the active display area. The front shell's outer transition has a 1 mm round above the original face-down print relief.

## Print and fit

Use the Bambu ABS profile for the actual machine/spool, 0.4 mm nozzle, approximately 0.2 mm layers and at least four walls. Use the print-oriented STLs without rescaling. Print **bezel_receiver_coupon** and **bezel_clip_coupon** first, then the existing **snap_fit_coupons** for the case latches. The receiver coupon contains a free shell spring; the clip coupon contains a rigid bezel hook.

The concealed shell arms have a nominal 14 mm span, 1 mm XY thickness and 2.4 mm depth, with a recessed 1.2 mm retaining land at each tip to clear the actual display housing. At the hook's roughly 13 mm effective span, 0.65 mm deflection gives about 0.58% calculated outer-fibre strain. This is a screening estimate, not a strength or fatigue rating. Check insertion, retention, free movement and repeated removal on actual ABS coupons.

Print the front and bezel visible-face down. The bezel perimeter expands at 45 degrees above its bed face; the rigid hook ramps are short, sloped features. The shell springs lie in the first face layers, with open clearance channels, so no floating beams or trapped supports are required. The optional 0.65 mm grooves need only short bridges. Inspect hook tips, arm roots and first-layer expansion before fitting.

Print the rear exterior on the bed. The eyelet's back rises at 45 degrees from the shell depth, keeping the shoulder supported as layers grow. Inspect the bore, taper, wall fusion and neck. Use sufficient wall/local infill settings to avoid a sparse core in the eyelet, and confirm them in the slicer. Determine strength with actual pull, twist and drop tests.

Seat the four bezel pads on the front face and press evenly until the hooks catch. **Removal requires access behind the front shell**: release its concealed arms gently with a nonmetallic tool, then lift the trim. This avoids visible release slots and accidental release in use. Do not pry against the display or force a binding bezel.

All carriers, buttons, hatch and four case latches are included unchanged in this complete B print set. Follow [the baseline board and internal assembly notes](ASSEMBLY_AND_PRINT_BASELINE_A.md), using this guide for B shell/trim assembly. The original A front has no bezel receivers and cannot accept this trim.

## Colours

- **Roddy:** cream face, black rear/buttons, **red bezel** and red centre button.
- **Avocado:** cream face, green rear/buttons, yellow bezel and amber centre button.
- **Commodore-inspired:** beige face, brown rear/buttons, brown engraved bezel and red centre button. This is a palette reference, without Commodore branding.
- A Roddy yellow-bezel alternative remains available separately; red is the default.

All colour parts print separately; a multi-material printer is unnecessary. [Further accessory ideas](NOSTALGIA_OPTIONS.md) remain concepts unless present in the parts manifest.

[Fit report](reports/FIT_CHECK.json) · [Overall dimensions](ASSEMBLY_ENVELOPE.json) · [Parts manifest](PARTS_MANIFEST.json). Nominal CAD fit does not establish shrinkage allowance, snap life, ring strength, harness assembly, charging performance or retail readiness.
