# Shell B CAD previews

`RODDY.png`, `AVOCADO.png`, `COMMODORE_INSPIRED.png` and the named detail views are current full-check renders. Roddy uses a red bezel. `RODDY_YELLOW_ALTERNATIVE.png` is optional.

`REVISED_*` are quick exterior previews of the rounded trim and tapered shoulder, sent ahead of the full assembly check. `QUICK_*` and `RODDY_RED_BEZEL.png` show the earlier rejected exposed-slot design and straight loop; retained for visual comparison only. Do not use them as the current product reference.

`INSPECTION_GREEN.png` and the side/rear detail views use a green rear with camera fill lighting to make geometry visible; they do not redefine the Roddy colourway. Full internal electronic geometry remains in the checked CAD; a quick exterior view omits it.
